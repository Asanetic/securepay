const MosyColumnFactory = {

   //-- banking cols--//
  banking: ["record_id", "station_id", "shift_code", "record_date", "expected_sales_amount", "actual_banked_amount", "variance_amount", "variance_reason", "banked_by", "banked_on", "bank_reference_code", "banking_status", "payment_notes", "verified_by", "verified_on", "hive_site_id", "hive_site_name"],

   //-- business_branches cols--//
  business_branches: ["record_id", "branch_name", "branch_code", "location", "phone_number", "email", "manager_name", "manager_phone", "status", "created_on", "hive_site_id", "hive_site_name", "branch_logo"],

   //-- clients cols--//
  clients: ["record_id", "client_name", "client_type", "phone_number", "alt_phone", "email", "national_id", "kra_pin", "vehicle_plate", "contact_person", "payment_mode_preference", "credit_limit", "balance_due", "client_status", "loyalty_points", "physical_address", "county", "location_description", "registered_by", "registered_on", "last_transaction_on", "remarks", "created_on", "hive_site_id", "hive_site_name"],

   //-- companies cols--//
  companies: ["company_id", "business_no", "name", "mobile", "email", "business_name", "location", "specialty", "remark", "logo", "bank_name", "account_no", "pin_no", "swort_code", "hive_site_id", "hive_site_name"],

   //-- deposits_by_mode cols--//
  deposits_by_mode: ["record_id", "station_id", "date_deposited", "amount_deposited", "payment_mode", "ref_number", "shift_id", "deposit_file_id", "remark", "hive_site_id", "hive_site_name"],

   //-- expenses cols--//
  expenses: ["record_id", "expense_date", "expense_type", "amount", "remark", "hive_site_id", "hive_site_name", "station_id", "station_code", "station_name", "expense_name", "document_number"],

   //-- fuel_clients_vehicles cols--//
  fuel_clients_vehicles: ["record_id", "client_name", "client_code", "contact_number", "email", "vehicle_number_plate", "vehicle_type", "fuel_type", "status", "created_on", "station_id", "hive_site_id", "hive_site_name"],

   //-- fuel_deliveries cols--//
  fuel_deliveries: ["record_id", "fuel_station_id", "supplier_name", "fuel_type", "quantity_litres", "cost_per_litre", "total_cost", "delivered_by", "received_by_staff_id", "delivery_note_number", "delivery_date", "hive_site_id", "hive_site_name", "buying_price", "selling_price", "margin", "total_margin", "delivered_litres", "variance", "variance_value", "tank_reference"],

   //-- fuel_fleet cols--//
  fuel_fleet: ["record_id", "vehicle_name", "vehicle_number_plate", "vehicle_type", "fuel_type", "assigned_station_id", "driver_name", "driver_contact", "status", "created_on", "hive_site_id", "hive_site_name"],

   //-- fuel_inventory cols--//
  fuel_inventory: ["item_id", "item_name", "fuel_type", "buying_price", "selling_price", "fuel_grade", "current_stock_litres", "density_kg_per_m3", "volume_correction_factor", "manual_dip_reading_litres", "atg_reading_litres", "percentage_variance", "variance_reason_code", "tank_reference", "last_updated_on", "created_on", "item_code", "hive_site_id", "hive_site_name", "item_class_code", "item_type_code", "origin_nation_code", "package_unit_code", "quantity_unit_code", "tax_type_code", "default_unit_price", "stock_quantity", "item_bar_code", "itax_id", "fuel_grade_name"],

   //-- fuel_pump_nozzles cols--//
  fuel_pump_nozzles: ["record_id", "pump_id", "nozzle_label", "fuel_type", "calibration_factor", "status", "installed_on", "last_maintenance_date", "created_on", "hive_site_id", "hive_site_name", "tank_reference"],

   //-- fuel_pumps cols--//
  fuel_pumps: ["record_id", "fuel_station_id", "pump_name", "manufacturer", "model_number", "installation_date", "status", "created_on", "hive_site_id", "hive_site_name", "pump_id"],

   //-- fuel_sales cols--//
  fuel_sales: ["record_id", "fuel_station_id", "pump_nozzle_id", "vehicle_plate", "fuel_type", "quantity_sold_litres", "sale_price_per_litre", "total_amount", "sold_by_staff_id", "sale_method", "sale_date", "hive_site_id", "hive_site_name", "pump", "total_paid", "shift_id", "customer_id"],

   //-- fuel_staff cols--//
  fuel_staff: ["record_id", "station_id", "full_name", "staff_code", "position", "phone_number", "email", "employment_date", "status", "created_on", "hive_site_id", "hive_site_name", "login_password"],

   //-- fuel_stations cols--//
  fuel_stations: ["record_id", "station_name", "station_code", "country", "county", "region", "location", "contact_number", "email", "manager_name", "status", "latitude", "longitude", "google_maps_link", "opening_hours", "is_operational", "has_atg_system", "licence_number", "licence_expiry_date", "erp_integration_code", "till_number", "paybill_number", "bank_account_name", "bank_account_number", "default_payment_mode", "storage_capacity_litres", "additional_details", "created_on", "hive_site_id", "hive_site_name"],

   //-- fuel_suppliers cols--//
  fuel_suppliers: ["record_id", "supplier_name", "supplier_code", "contact_person", "phone_number", "email", "address", "hive_site_id", "hive_site_name", "pin_no"],

   //-- inventory cols--//
  inventory: ["item_id", "item_code", "item_name", "variance", "display_name", "item_type", "item_description", "buying_price", "selling_price", "available_quantity", "stock_alert", "tax_type", "tax_rate", "tax_amount", "shop_location", "selling_price_n_tax", "margin_price", "hive_site_id", "hive_site_name", "category", "sub_category", "photo", "item_class_code", "item_type_code", "origin_nation_code", "package_unit_code", "quantity_unit_code", "tax_type_code", "default_unit_price", "stock_quantity", "item_bar_code", "itax_id"],

   //-- octane_cellulant_transactions cols--//
  octane_cellulant_transactions: ["cellulant_txn_id", "merchant_id", "loan_id", "txn_type", "txn_direction", "amount", "currency", "status", "raw_payload", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_loan_events cols--//
  octane_loan_events: ["event_id", "loan_id", "merchant_id", "event_type", "event_note", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_loan_repayment_schedule cols--//
  octane_loan_repayment_schedule: ["schedule_id", "loan_id", "merchant_id", "expected_amount", "paid_amount", "due_date", "schedule_status", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_loan_requests cols--//
  octane_loan_requests: ["loan_request_id", "station_id", "principal_amount", "interest_rate", "interest_amount", "total_repayable", "tenure_days", "send_to", "payment_type", "recipient_name", "recipient_email", "recipient_phone", "receiving_account_number", "receiving_bank_name", "receiving_bank_code", "receiving_branch_name", "purpose", "request_status", "approved_by", "approval_date", "rejection_reason", "disbursement_txn_id", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_loans cols--//
  octane_loans: ["loan_id", "merchant_id", "principal_amount", "fee_amount", "disbursed_amount", "outstanding_balance", "repayment_percentage", "tenure_days", "disbursement_txn_id", "loan_status", "approval_date", "disbursement_date", "settlement_date", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_merchants cols--//
  octane_merchants: ["merchant_id", "station_name", "cellulant_merchant_code", "settlement_account_name", "settlement_account_number", "settlement_bank_code", "phone_number", "email", "status", "reg_date", "hive_site_id", "hive_site_name"],

   //-- octane_payout_confirmations cols--//
  octane_payout_confirmations: ["payout_confirmation_id", "station_id", "payout_request_id", "cellulant_txn_id", "cellulant_reference", "amount", "currency", "response_code", "response_message", "status", "raw_payload", "confirmed_at", "hive_site_id", "hive_site_name"],

   //-- octane_payout_requests cols--//
  octane_payout_requests: ["payout_request_id", "station_id", "request_amount", "currency", "destination_type", "recipient_name", "recipient_phone", "recipient_email", "account_number", "bank_name", "bank_code", "branch_name", "request_note", "request_status", "cellulant_reference", "requested_at", "processed_at", "hive_site_id", "hive_site_name"],

   //-- octane_suppliers cols--//
  octane_suppliers: ["recipient_id", "station_id", "recipient_type", "recipient_name", "contact_person", "recipient_phone", "recipient_email", "payment_type", "account_number", "bank_name", "bank_code", "branch_name", "mobile_money_number", "mobile_money_provider", "is_default", "status", "created_at", "swift_code", "hive_site_id", "hive_site_name"],

   //-- octane_wallet_ledger cols--//
  octane_wallet_ledger: ["ledger_id", "wallet_id", "merchant_id", "loan_id", "txn_type", "txn_direction", "amount", "reference_id", "external_txn_id", "description", "created_at", "hive_site_id", "hive_site_name"],

   //-- octane_wallets cols--//
  octane_wallets: ["wallet_id", "merchant_id", "wallet_type", "wallet_balance", "status", "created_at", "hive_site_id", "hive_site_name", "wallet_name"],

   //-- page_manifest_ cols--//
  page_manifest_: ["manikey", "page_group", "site_id", "page_url", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- sales_analysis cols--//
  sales_analysis: ["record_id", "station_id", "opening", "closing", "product_name", "product_code", "sales_date", "hive_site_id", "hive_site_name", "rate", "pump_name", "shift_code", "attendant", "nozzle_label"],

   //-- sales_kra_logs cols--//
  sales_kra_logs: ["record_id", "sale_order_id", "kra_sale_id", "request_payload", "response_payload", "status", "message", "created_at", "hive_site_id", "hive_site_name"],

   //-- sales_kra_tax_summary cols--//
  sales_kra_tax_summary: ["record_id", "sale_order_id", "taxable_amount_a", "taxable_amount_b", "taxable_amount_c", "taxable_amount_d", "taxable_amount_e", "tax_rate_a", "tax_rate_b", "tax_rate_c", "tax_rate_d", "tax_rate_e", "tax_amount_a", "tax_amount_b", "tax_amount_c", "tax_amount_d", "tax_amount_e", "created_at", "hive_site_id", "hive_site_name"],

   //-- sales_order_items cols--//
  sales_order_items: ["record_id", "order_id", "product_name", "product_code", "quantity", "unit_price", "tax_amount", "total_price", "created_at", "updated_at", "hive_site_id", "hive_site_name", "buying_price", "margin_price", "item_category", "custom_field_1", "custom_field_2", "custom_field_3", "custom_field_4", "custom_field_5", "custom_field_6", "custom_field_7", "custom_field_8", "custom_field_9", "custom_field_10", "location", "location_id", "sold_by", "shift_id", "kra_item_id", "kra_item_code", "kra_tax_type", "kra_tax_rate", "kra_tax_amount", "kra_synced"],

   //-- sales_order_payments cols--//
  sales_order_payments: ["record_id", "order_id", "order_total", "payment_date", "payment_method", "amount", "created_at", "updated_at", "hive_site_id", "hive_site_name", "ref_no", "location", "location_id", "customer_id", "customer_name", "customer_tel", "sold_by", "shift_id"],

   //-- sales_orders cols--//
  sales_orders: ["record_id", "receipt_number", "customer_name", "customer_phone", "order_date", "total_amount", "tax", "discount", "grand_total", "sold_by", "sold_name", "sale_status", "sale_type", "created_at", "updated_at", "hive_site_id", "hive_site_name", "margin", "total_paid", "customer_id", "location", "location_id", "shift", "kra_sale_id", "kra_status", "kra_receipt_type", "kra_serial_number", "kra_receipt_number", "kra_invoice_number", "kra_qr_url", "kra_verified_at"],

   //-- sales_point cols--//
  sales_point: ["record_id", "sales_point_name", "branch_id", "location_name", "description", "reg_date", "hive_site_id", "hive_site_name"],

   //-- shifts cols--//
  shifts: ["record_id", "shift_code", "shift_name", "opened_by", "closed_by", "open_time", "close_time", "start_cash", "end_cash", "status", "reconcile_notes", "location_id", "created_at", "updated_at", "hive_site_id", "hive_site_name"],

   //-- stock_history cols--//
  stock_history: ["stock_key_sign", "item_id", "item_name", "item_code", "quantity", "buying_price", "selling_price", "stock_alert", "tax_type", "tax_rate", "tax_amount", "item_description", "supplier", "supplier_name", "shop_location", "receipt_no", "invoice_no", "payment_mode", "inventory_date", "selling_price_n_tax", "total_buying_price", "margin_price", "total_units", "unit_per_dz", "signature", "invoice_amount", "invoice_amount_paid", "invoice_bal_amount", "hive_site_id", "hive_site_name"],

   //-- suppliers cols--//
  suppliers: ["record_id", "supplier_name", "supplier_code", "contact_person", "address", "phone_number", "pin_no", "speciality", "email", "hive_site_id", "hive_site_name"],

   //-- system_module_manifest_ cols--//
  system_module_manifest_: ["record_id", "component_name", "module_key", "module_name", "permission_type", "capability_key", "access_name", "relative_path", "hive_site_id", "hive_site_name"],

   //-- system_role_bundles cols--//
  system_role_bundles: ["record_id", "bundle_id", "bundle_name", "remark", "hive_site_id", "hive_site_name"],

   //-- system_shifts cols--//
  system_shifts: ["record_id", "location_id", "shift_name", "shift_code", "opening_time", "closing_time", "remark", "created_by", "reg_date", "hive_site_id", "hive_site_name"],

   //-- system_users cols--//
  system_users: ["record_id", "name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in", "project_id", "project_name", "user_role"],

   //-- tank_devices cols--//
  tank_devices: ["record_id", "device_id", "tank_id", "device_name", "device_type", "protocol", "serial_number", "remark", "install_date", "status", "last_seen", "reg_date", "hive_site_id", "hive_site_name", "station_id"],

   //-- tank_level_history cols--//
  tank_level_history: ["movement_id", "tank_id", "device_id", "movement_type", "liters_in", "liters_out", "new_volume", "reference_no", "remarks", "movement_time", "reg_date", "hive_site_id", "hive_site_name"],

   //-- tank_logs cols--//
  tank_logs: ["log_id", "tank_id", "device_id", "level_mm", "volume_liters", "temperature", "water_level", "log_source", "logged_at", "hive_site_id", "hive_site_name"],

   //-- tanks cols--//
  tanks: ["tank_id", "tank_name", "fuel_type", "capacity_liters", "current_liters", "site_location", "min_threshold", "max_threshold", "status", "reg_date", "hive_site_id", "hive_site_name"],

   //-- telematics_logs cols--//
  telematics_logs: ["record_id", "device_id", "device_type", "raw_data", "parsed_data", "reading_value", "reading_type", "remarks", "device_timestamp", "server_timestamp", "hive_site_id", "hive_site_name"],

   //-- user_bundle_role_functions cols--//
  user_bundle_role_functions: ["record_id", "bundle_id", "bundle_name", "role_id", "role_name", "remark", "hive_site_id", "hive_site_name"],

   //-- user_manifest_ cols--//
  user_manifest_: ["admin_mkey", "user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name", "project_id", "project_name"],


};
export default MosyColumnFactory;